import './App.css';
import PageHeader from './components/PageHeader';
import Addbooks from './pages/Addbooks';
import Books from './pages/Books';
import Members from './pages/Members';
import AddMembers from './pages/AddMembers';
import Addchekout from './pages/Checkout';
import Addreturn from './pages/Return';
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <PageHeader />
      </div>
      <Routes>
        <Route path="/addbook" element={<Addbooks />} />
        <Route path="/" element={<Books />} />
        <Route path="/books" element={<Books />} />
        <Route path="/members" element={<Members />} />
        <Route path="/addmember" element={<AddMembers />} />
        <Route path="/checkoutbook" element={<Addchekout/>} />
        <Route path="/returnbook" element={<Addreturn/>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
