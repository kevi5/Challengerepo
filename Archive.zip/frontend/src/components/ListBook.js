import React from 'react'

const ListBook = ({ book }) => {
    return (
        <div>
            <h3>{book.book_id}</h3>
            <h3>{book.book_name}</h3>
            <h3>{book.copies}</h3>
        </div>
    )
}

export default ListBook
