import React from 'react'

const PageHeader = () => {
  return (
    <div>
      <h3>Book Management</h3>
    </div>
  )
}

export default PageHeader



