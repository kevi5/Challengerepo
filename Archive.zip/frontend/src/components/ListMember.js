import React from 'react'

const Listmember = ({ member }) => {
    return (
        <div>
            <h3>{member.member_id}</h3>
            <h3>{member.member_name}</h3>
        </div>
    )
}

export default Listmember
