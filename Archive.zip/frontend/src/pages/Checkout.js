import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'

function getCsrfToken() {
    const csrfToken = document.cookie.split('; ').find(row => row.startsWith('csrftoken='));
    return csrfToken ? csrfToken.split('=')[1] : null;
}

const Addcheckout = () => {

    let [book, setBook] = useState([])
    useEffect(() => {
    }, [])

    let [member, setmember] = useState([])
    useEffect(() => {
    }, [])


    let addcheckout = async () => {
        const csrfToken = getCsrfToken();
        let response = await fetch('http://localhost:8000/api/checkoutbook/' + book.body + '/' + member.body + '/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken,
            },
        });

        let data = await response.json();
        console.log(data);
    }

    return (
        <div>
            <h1>Add Checkout</h1>
            <h3>Book name</h3>
            <input onChange={(e) => { setBook({ ...book, 'body': e.target.value }) }} type="text" placeholder="Enter book name" />
            <h3>member name</h3>
            <input onChange={(e) => { setmember({ ...member, 'body': e.target.value }) }} type="text" placeholder="Enter member name" />
            <button onClick={addcheckout}>Add checkout</button>
        </div>
    )
}

export default Addcheckout
