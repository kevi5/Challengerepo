import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'

function getCsrfToken() {
    const csrfToken = document.cookie.split('; ').find(row => row.startsWith('csrftoken='));
    return csrfToken ? csrfToken.split('=')[1] : null;
}

const Addmembers = () => {

    let { name:member_name } = useParams();
    let [member, setmember] = useState([])
    useEffect(() => {
    }, [])


    let addmember = async () => {
        const csrfToken = getCsrfToken(); 
        let response = await fetch('http://localhost:8000/api/addmember/' + member.body + '/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken,
            },
        });
    
        let data = await response.json();
        console.log(data);
    }

  return (
    <div>
        <h1>Add members</h1>
        <h3>member name</h3>
        <input onChange={(e) => {setmember({ ...member, 'body': e.target.value})}} type="text" placeholder="Enter member name" />
        <button onClick={addmember}>Add member</button>
    </div>
  )
}

export default Addmembers
