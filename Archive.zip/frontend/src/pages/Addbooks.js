import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'

function getCsrfToken() {
    const csrfToken = document.cookie.split('; ').find(row => row.startsWith('csrftoken='));
    return csrfToken ? csrfToken.split('=')[1] : null;
}

const Addbooks = () => {

    let { name:book_name } = useParams();
    let [book, setBook] = useState([])
    useEffect(() => {
    }, [])


    let addbook = async () => {
        const csrfToken = getCsrfToken(); 
        let response = await fetch('http://localhost:8000/api/addbook/' + book.body + '/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken,
            },
        });
    
        let data = await response.json();
        console.log(data);
    }

  return (
    <div>
        <h1>Add Books</h1>
        <h3>Book name</h3>
        <input onChange={(e) => {setBook({ ...book, 'body': e.target.value})}} type="text" placeholder="Enter book name" />
        <button onClick={addbook}>Add book</button>
    </div>
  )
}

export default Addbooks
