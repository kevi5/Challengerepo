import React, { useState, useEffect } from 'react'
import ListBook from '../components/ListBook'

const NotesListPage = () => {
    let [books, setBooks] = useState([])

    useEffect(() => {
        getBooks()
    }, [])

    let getBooks = async () => {
        let response = await fetch('http://localhost:8000/api/books/')
        let data = await response.json()
        // console.log(data)
        setBooks(data)
    }

    return (
        <div>
            <div>
                <h1>Books</h1>
                {books.map(book => (
                    <ListBook key={book.book_id} book={book} />
                ))}
            </div>
        </div>
    )
}

export default NotesListPage