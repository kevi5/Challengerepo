import React, { useState, useEffect } from 'react'
import Listmember from '../components/ListMember'

const NotesListPage = () => {
    let [members, setmembers] = useState([])

    useEffect(() => {
        getmembers()
    }, [])

    let getmembers = async () => {
        let response = await fetch('http://localhost:8000/api/members/')
        let data = await response.json()
        // console.log(data)
        setmembers(data)
    }

    return (
        <div>
            <div>
                <h1>members</h1>
                {members.map(member => (
                    <Listmember key={member.member_id} member={member} />
                ))}
            </div>
        </div>
    )
}

export default NotesListPage